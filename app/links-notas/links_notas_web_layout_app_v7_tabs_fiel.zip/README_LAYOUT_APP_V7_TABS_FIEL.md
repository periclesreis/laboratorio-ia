# Links & Notas Web — v7 abas fiéis ao mobile

Ajustes feitos com base nos arquivos enviados:

- Rodapé ajustado conforme `_layout.tsx`:
  - Home
  - Histórico
  - Sobre
  - Configurações
- Home ajustada com:
  - título central `Links & Notas`
  - subtítulo do mobile
  - busca fixa no rodapé da tela, acima das abas
  - cards gradientes iguais aos do mobile
- Histórico ajustado com:
  - título e subtítulo iguais
  - cards brancos com borda roxa
  - ícones por tipo
  - botão `Limpar histórico` no padrão mobile
- Sobre ajustado com:
  - logo ❤️
  - nome `Links Úteis`
  - versão
  - seções Sobre o Aplicativo, Desenvolvedor, Categorias, Contato, Redes Sociais e Histórico de Versões
- Configurações ajustada com:
  - título/subtítulo iguais
  - card `💾 Backup`
  - botões `Exportar backup .lu` e `Restaurar backup .lu`
  - seção `O que entra no backup?`
  - resumo de dados locais

Copie para:

```txt
D:\DEV\site\app\links-notas\page.tsx
```

Teste:

```bat
cd /d "D:\DEV\site"
npm run dev
```
