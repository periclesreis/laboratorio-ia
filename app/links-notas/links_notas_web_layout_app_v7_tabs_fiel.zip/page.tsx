"use client";

import { useEffect, useMemo, useState, type ReactNode } from "react";

type Area = "home" | "links" | "notes" | "history" | "about" | "settings";
type Mode = "all" | "folders" | "items";

type LinkFolder = {
  id: string;
  title: string;
  icon: string;
  createdAt: string;
  updatedAt: string;
};

type CustomLink = {
  id: string;
  title: string;
  url: string;
  folderId?: string | null;
  createdAt: string;
  updatedAt: string;
};

type NoteFolder = {
  id: string;
  name: string;
  icon: string;
  createdAt: string;
  updatedAt: string;
};

type NoteItem = {
  id: string;
  title: string;
  content: string;
  folderId?: string | null;
  color?: string | null;
  createdAt: string;
  updatedAt: string;
};

type AppData = {
  customFolders: LinkFolder[];
  customLinks: CustomLink[];
  noteFolders: NoteFolder[];
  notes: NoteItem[];
};

type Target =
  | { kind: "link"; item: CustomLink }
  | { kind: "linkFolder"; item: LinkFolder }
  | { kind: "note"; item: NoteItem }
  | { kind: "noteFolder"; item: NoteFolder };

type HistoryEntry = {
  id: string;
  title: string;
  subtitle: string;
  area: "links" | "notes";
  targetId?: string | null;
  kind: "link" | "note" | "linkFolder" | "noteFolder";
  createdAt: string;
};

type ModalName = "link" | "linkFolder" | "note" | "noteFolder" | "move" | "color" | null;

const STORAGE_KEY = "links-notas-web-layout-app-v3";

const EMPTY_DATA: AppData = {
  customFolders: [],
  customLinks: [],
  noteFolders: [],
  notes: [],
};

const CARD_GRADIENT = "linear-gradient(135deg, #60A5FA 0%, #3B82F6 50%, #8B5CF6 100%)";

const COLORS = {
  background: "#F8FAFC",
  surface: "#FFFFFF",
  foreground: "#0F172A",
  muted: "#64748B",
  border: "#E2E8F0",
  primary: "#2563EB",
  purple: "#7C3AED",
  folderBackground: "#E0F2FE",
  folderBorder: "#38BDF8",
  actionBar: "#E5E7EB",
  actionBorder: "#94A3B8",
};

const APP_VERSION = "1.0.0";

const ICONS = ["📁", "⭐", "📌", "📚", "📝", "🔗", "💼", "🏠", "❤️", "✅"];

const NOTE_COLORS = [
  { label: "Padrão", value: null },
  { label: "Azul escuro", value: "#1e3a8a" },
  { label: "Azul médio", value: "#1d4ed8" },
  { label: "Azul vivo", value: "#2563eb" },
  { label: "Azul céu", value: "#0284c7" },
  { label: "Verde escuro", value: "#14532d" },
  { label: "Verde folha", value: "#166534" },
  { label: "Verde vivo", value: "#15803d" },
  { label: "Verde petróleo", value: "#047857" },
  { label: "Vermelho escuro", value: "#7f1d1d" },
  { label: "Vermelho clássico", value: "#991b1b" },
  { label: "Vermelho vivo", value: "#b91c1c" },
  { label: "Vermelho vinho", value: "#be123c" },
  { label: "Amarelo escuro", value: "#854d0e" },
  { label: "Mostarda", value: "#a16207" },
  { label: "Dourado", value: "#b45309" },
  { label: "Âmbar", value: "#92400e" },
  { label: "Roxo", value: "#581c87" },
  { label: "Cinza", value: "#374151" },
];

function makeId(prefix: string) {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return `${prefix}-${crypto.randomUUID()}`;
  }

  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function nowIso() {
  return new Date().toISOString();
}

function normalizeUrl(url: string) {
  const clean = url.trim();

  if (!clean) {
    return "";
  }

  return /^https?:\/\//i.test(clean) ? clean : `https://${clean}`;
}

function getHost(url: string) {
  try {
    return new URL(url).host.replace(/^www\./, "");
  } catch {
    return url;
  }
}

function formatDate(dateString?: string) {
  if (!dateString) {
    return "";
  }

  const date = new Date(dateString);

  if (Number.isNaN(date.getTime())) {
    return "";
  }

  return date.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "short",
  });
}

export default function LinksNotasWebPage() {
  const [area, setArea] = useState<Area>("home");
  const [data, setData] = useState<AppData>(EMPTY_DATA);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [homeSearch, setHomeSearch] = useState("");
  const [linkMode, setLinkMode] = useState<Mode>("all");
  const [noteMode, setNoteMode] = useState<Mode>("all");
  const [linkFolderId, setLinkFolderId] = useState<string | null>(null);
  const [noteFolderId, setNoteFolderId] = useState<string | null>(null);

  const [target, setTarget] = useState<Target | null>(null);
  const [fabOpen, setFabOpen] = useState(false);
  const [backupOpen, setBackupOpen] = useState(false);
  const [modal, setModal] = useState<ModalName>(null);

  const [editId, setEditId] = useState<string | null>(null);
  const [fieldOne, setFieldOne] = useState("");
  const [fieldTwo, setFieldTwo] = useState("");
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const [selectedIcon, setSelectedIcon] = useState("📁");
  const [importUrl, setImportUrl] = useState("");

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      const rawHistory = window.localStorage.getItem(`${STORAGE_KEY}:history`);

      if (raw) {
        setData(JSON.parse(raw));
      }

      if (rawHistory) {
        setHistory(JSON.parse(rawHistory));
      }
    } catch {
      setData(EMPTY_DATA);
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data]);

  useEffect(() => {
    window.localStorage.setItem(`${STORAGE_KEY}:history`, JSON.stringify(history));
  }, [history]);

  const linkFolders = useMemo(
    () => data.customFolders.slice().sort((a, b) => a.title.localeCompare(b.title)),
    [data.customFolders],
  );

  const noteFolders = useMemo(
    () => data.noteFolders.slice().sort((a, b) => a.name.localeCompare(b.name)),
    [data.noteFolders],
  );

  const links = useMemo(
    () => data.customLinks.slice().sort((a, b) => a.title.localeCompare(b.title)),
    [data.customLinks],
  );

  const notes = useMemo(
    () =>
      data.notes
        .slice()
        .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()),
    [data.notes],
  );

  const activeLinkFolder = useMemo(
    () => linkFolders.find((folder) => folder.id === linkFolderId) ?? null,
    [linkFolders, linkFolderId],
  );

  const activeNoteFolder = useMemo(
    () => noteFolders.find((folder) => folder.id === noteFolderId) ?? null,
    [noteFolders, noteFolderId],
  );

  const visibleLinkFolders = useMemo(() => {
    if (linkFolderId || (linkMode !== "all" && linkMode !== "folders")) {
      return [];
    }

    return linkFolders;
  }, [linkFolderId, linkMode, linkFolders]);

  const visibleLinks = useMemo(() => {
    if (linkMode !== "all" && linkMode !== "items") {
      return [];
    }

    return links.filter((link) => (linkFolderId ? link.folderId === linkFolderId : !link.folderId));
  }, [linkFolderId, linkMode, links]);

  const visibleNoteFolders = useMemo(() => {
    if (noteFolderId || (noteMode !== "all" && noteMode !== "folders")) {
      return [];
    }

    return noteFolders;
  }, [noteFolderId, noteMode, noteFolders]);

  const visibleNotes = useMemo(() => {
    if (noteMode !== "all" && noteMode !== "items") {
      return [];
    }

    return notes.filter((note) => (noteFolderId ? note.folderId === noteFolderId : !note.folderId));
  }, [noteFolderId, noteMode, notes]);

  const homeResults = useMemo(() => {
    const query = homeSearch.trim().toLowerCase();

    if (!query) {
      return [];
    }

    const foundLinks = links
      .filter((link) => `${link.title} ${link.url} ${getHost(link.url)}`.toLowerCase().includes(query))
      .slice(0, 5);

    const foundNotes = notes
      .filter((note) => `${note.title} ${note.content}`.toLowerCase().includes(query))
      .slice(0, 5);

    const foundLinkFolders = linkFolders
      .filter((folder) => `${folder.icon} ${folder.title}`.toLowerCase().includes(query))
      .slice(0, 4);

    const foundNoteFolders = noteFolders
      .filter((folder) => `${folder.icon} ${folder.name}`.toLowerCase().includes(query))
      .slice(0, 4);

    return [
      ...foundLinkFolders.map((item) => ({ kind: "linkFolder" as const, item })),
      ...foundLinks.map((item) => ({ kind: "link" as const, item })),
      ...foundNoteFolders.map((item) => ({ kind: "noteFolder" as const, item })),
      ...foundNotes.map((item) => ({ kind: "note" as const, item })),
    ];
  }, [homeSearch, links, notes, linkFolders, noteFolders]);

  function addHistory(entry: Omit<HistoryEntry, "id" | "createdAt">) {
    const createdAt = nowIso();

    setHistory((current) => [
      {
        id: makeId("history"),
        createdAt,
        ...entry,
      },
      ...current.filter(
        (item) =>
          !(
            item.kind === entry.kind &&
            item.targetId === entry.targetId &&
            item.title === entry.title
          ),
      ),
    ].slice(0, 80));
  }

  function openFooterArea(nextArea: Area) {
    closeSelection();
    closeModal();
    setFabOpen(false);
    setArea(nextArea);
    setLinkFolderId(null);
    setNoteFolderId(null);
  }

  function closeSelection() {
    setTarget(null);
    setFabOpen(false);
  }

  function closeModal() {
    setModal(null);
  }

  function goHome() {
    closeSelection();
    closeModal();
    setArea("home");
    setLinkFolderId(null);
    setNoteFolderId(null);
  }

  function handleBack() {
    if (area === "links" && linkFolderId) {
      setLinkFolderId(null);
      closeSelection();
      return;
    }

    if (area === "notes" && noteFolderId) {
      setNoteFolderId(null);
      closeSelection();
      return;
    }

    goHome();
  }

  function openTargetItem(nextTarget: Target) {
    if (nextTarget.kind === "link") {
      addHistory({
        title: nextTarget.item.title,
        subtitle: getHost(nextTarget.item.url),
        area: "links",
        kind: "link",
        targetId: nextTarget.item.id,
      });
      window.open(nextTarget.item.url, "_blank", "noopener,noreferrer");
      return;
    }

    if (nextTarget.kind === "linkFolder") {
      addHistory({
        title: nextTarget.item.title,
        subtitle: "Pasta de Meus Links",
        area: "links",
        kind: "linkFolder",
        targetId: nextTarget.item.id,
      });
      setArea("links");
      setLinkFolderId(nextTarget.item.id);
      closeSelection();
      return;
    }

    if (nextTarget.kind === "note") {
      addHistory({
        title: nextTarget.item.title || "Sem título",
        subtitle: "Anotação",
        area: "notes",
        kind: "note",
        targetId: nextTarget.item.id,
      });
      startNote(nextTarget.item);
      return;
    }

    addHistory({
      title: nextTarget.item.name,
      subtitle: "Pasta de Anotações",
      area: "notes",
      kind: "noteFolder",
      targetId: nextTarget.item.id,
    });
    setArea("notes");
    setNoteFolderId(nextTarget.item.id);
    closeSelection();
  }

  function startLink(item?: CustomLink) {
    setEditId(item?.id ?? null);
    setFieldOne(item?.title ?? "");
    setFieldTwo(item?.url ?? "");
    setSelectedFolderId(item?.folderId ?? linkFolderId ?? null);
    setFabOpen(false);
    setTarget(null);
    setModal("link");
  }

  function saveLink() {
    const title = fieldOne.trim();
    const url = normalizeUrl(fieldTwo);
    const timestamp = nowIso();

    if (!title) {
      alert("Digite o nome do link.");
      return;
    }

    if (!url) {
      alert("Digite o endereço do link.");
      return;
    }

    setData((current) => {
      if (editId) {
        return {
          ...current,
          customLinks: current.customLinks.map((link) =>
            link.id === editId
              ? {
                  ...link,
                  title,
                  url,
                  folderId: selectedFolderId,
                  updatedAt: timestamp,
                }
              : link,
          ),
        };
      }

      return {
        ...current,
        customLinks: [
          ...current.customLinks,
          {
            id: makeId("link"),
            title,
            url,
            folderId: selectedFolderId,
            createdAt: timestamp,
            updatedAt: timestamp,
          },
        ],
      };
    });

    closeModal();
  }

  function startLinkFolder(item?: LinkFolder) {
    setEditId(item?.id ?? null);
    setFieldOne(item?.title ?? "");
    setSelectedIcon(item?.icon ?? "📁");
    setFabOpen(false);
    setTarget(null);
    setModal("linkFolder");
  }

  function saveLinkFolder() {
    const title = fieldOne.trim();
    const timestamp = nowIso();

    if (!title) {
      alert("Digite o nome da pasta.");
      return;
    }

    setData((current) => {
      if (editId) {
        return {
          ...current,
          customFolders: current.customFolders.map((folder) =>
            folder.id === editId
              ? {
                  ...folder,
                  title,
                  icon: selectedIcon,
                  updatedAt: timestamp,
                }
              : folder,
          ),
        };
      }

      return {
        ...current,
        customFolders: [
          ...current.customFolders,
          {
            id: makeId("link-folder"),
            title,
            icon: selectedIcon,
            createdAt: timestamp,
            updatedAt: timestamp,
          },
        ],
      };
    });

    closeModal();
  }

  function startNote(item?: NoteItem) {
    setEditId(item?.id ?? null);
    setFieldOne(item?.title ?? "");
    setFieldTwo(item?.content ?? "");
    setSelectedFolderId(item?.folderId ?? noteFolderId ?? null);
    setFabOpen(false);
    setTarget(null);
    setModal("note");
  }

  function saveNote() {
    const title = fieldOne.trim() || fieldTwo.trim().split("\n")[0]?.slice(0, 48) || "Sem título";
    const timestamp = nowIso();

    if (!title.trim() && !fieldTwo.trim()) {
      alert("Digite um título ou uma anotação.");
      return;
    }

    setData((current) => {
      if (editId) {
        return {
          ...current,
          notes: current.notes.map((note) =>
            note.id === editId
              ? {
                  ...note,
                  title,
                  content: fieldTwo,
                  folderId: selectedFolderId,
                  updatedAt: timestamp,
                }
              : note,
          ),
        };
      }

      return {
        ...current,
        notes: [
          ...current.notes,
          {
            id: makeId("note"),
            title,
            content: fieldTwo,
            folderId: selectedFolderId,
            color: null,
            createdAt: timestamp,
            updatedAt: timestamp,
          },
        ],
      };
    });

    closeModal();
  }

  function startNoteFolder(item?: NoteFolder) {
    setEditId(item?.id ?? null);
    setFieldOne(item?.name ?? "");
    setSelectedIcon(item?.icon ?? "📁");
    setFabOpen(false);
    setTarget(null);
    setModal("noteFolder");
  }

  function saveNoteFolder() {
    const name = fieldOne.trim();
    const timestamp = nowIso();

    if (!name) {
      alert("Digite o nome da pasta.");
      return;
    }

    setData((current) => {
      if (editId) {
        return {
          ...current,
          noteFolders: current.noteFolders.map((folder) =>
            folder.id === editId
              ? {
                  ...folder,
                  name,
                  icon: selectedIcon,
                  updatedAt: timestamp,
                }
              : folder,
          ),
        };
      }

      return {
        ...current,
        noteFolders: [
          ...current.noteFolders,
          {
            id: makeId("note-folder"),
            name,
            icon: selectedIcon,
            createdAt: timestamp,
            updatedAt: timestamp,
          },
        ],
      };
    });

    closeModal();
  }

  function editTarget() {
    if (!target) {
      return;
    }

    if (target.kind === "link") startLink(target.item);
    if (target.kind === "linkFolder") startLinkFolder(target.item);
    if (target.kind === "note") startNote(target.item);
    if (target.kind === "noteFolder") startNoteFolder(target.item);
  }

  function deleteTarget() {
    if (!target) {
      return;
    }

    const label =
      target.kind === "noteFolder"
        ? target.item.name
        : target.kind === "linkFolder"
          ? target.item.title
          : target.item.title;

    if (!window.confirm(`Excluir "${label}"?`)) {
      return;
    }

    setData((current) => {
      if (target.kind === "link") {
        return {
          ...current,
          customLinks: current.customLinks.filter((link) => link.id !== target.item.id),
        };
      }

      if (target.kind === "linkFolder") {
        return {
          ...current,
          customFolders: current.customFolders.filter((folder) => folder.id !== target.item.id),
          customLinks: current.customLinks.map((link) =>
            link.folderId === target.item.id ? { ...link, folderId: null } : link,
          ),
        };
      }

      if (target.kind === "note") {
        return {
          ...current,
          notes: current.notes.filter((note) => note.id !== target.item.id),
        };
      }

      return {
        ...current,
        noteFolders: current.noteFolders.filter((folder) => folder.id !== target.item.id),
        notes: current.notes.map((note) =>
          note.folderId === target.item.id ? { ...note, folderId: null } : note,
        ),
      };
    });

    closeSelection();
  }

  function moveTarget(folderId: string | null) {
    if (!target) {
      return;
    }

    const timestamp = nowIso();

    setData((current) => {
      if (target.kind === "link") {
        return {
          ...current,
          customLinks: current.customLinks.map((link) =>
            link.id === target.item.id
              ? {
                  ...link,
                  folderId,
                  updatedAt: timestamp,
                }
              : link,
          ),
        };
      }

      if (target.kind === "note") {
        return {
          ...current,
          notes: current.notes.map((note) =>
            note.id === target.item.id
              ? {
                  ...note,
                  folderId,
                  updatedAt: timestamp,
                }
              : note,
          ),
        };
      }

      return current;
    });

    closeSelection();
    closeModal();
  }

  function applyColor(color: string | null) {
    if (!target || target.kind !== "note") {
      return;
    }

    const timestamp = nowIso();

    setData((current) => ({
      ...current,
      notes: current.notes.map((note) =>
        note.id === target.item.id
          ? {
              ...note,
              color,
              updatedAt: timestamp,
            }
          : note,
      ),
    }));

    closeSelection();
    closeModal();
  }

  async function shareTarget() {
    if (!target) {
      return;
    }

    const text =
      target.kind === "link"
        ? `${target.item.title}\n${target.item.url}`
        : target.kind === "note"
          ? `${target.item.title}\n\n${target.item.content}`
          : target.kind === "linkFolder"
            ? target.item.title
            : target.item.name;

    if (navigator.share) {
      try {
        await navigator.share({ text });
      } catch {}
      return;
    }

    alert(text);
  }

  function exportBackup() {
    const payload = JSON.stringify(
      {
        app: "Links & Notas",
        version: 1,
        exportedAt: nowIso(),
        ...data,
      },
      null,
      2,
    );

    const blob = new Blob([payload], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");

    anchor.href = url;
    anchor.download = `links-notas-backup-${new Date().toISOString().slice(0, 10)}.lu`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  function importPayload(payload: any) {
    const imported: AppData = {
      customFolders: Array.isArray(payload.customFolders) ? payload.customFolders : [],
      customLinks: Array.isArray(payload.customLinks) ? payload.customLinks : [],
      noteFolders: Array.isArray(payload.noteFolders) ? payload.noteFolders : [],
      notes: Array.isArray(payload.notes) ? payload.notes : [],
    };

    setData(imported);
    setBackupOpen(false);
    alert("Backup importado e salvo neste navegador.");
  }

  async function importByUrl() {
    const url = importUrl.trim();

    if (!url) {
      alert("Cole o link do backup.");
      return;
    }

    const response = await fetch(url);
    const payload = await response.json();

    importPayload(payload);
    setImportUrl("");
  }

  function clearLocalData() {
    if (!window.confirm("Apagar todos os dados locais deste navegador?")) {
      return;
    }

    setData(EMPTY_DATA);
    window.localStorage.removeItem(STORAGE_KEY);
    closeSelection();
    setBackupOpen(false);
  }

  function renderHeader(title: string, subtitle?: string) {
    return (
      <header className="border-b border-slate-200 bg-[#F8FAFC] px-4 py-3">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleBack}
            className="-ml-1 px-1 text-4xl leading-none text-slate-900"
            aria-label="Voltar"
          >
            ‹
          </button>

          <div className="min-w-0 flex-1">
            <h1 className="truncate text-[24px] font-black text-slate-950">{title}</h1>
            {subtitle && <p className="mt-0.5 truncate text-[13px] text-slate-500">{subtitle}</p>}
          </div>

          <button
            type="button"
            onClick={() => setBackupOpen(true)}
            className="rounded-full border border-slate-200 bg-white px-3 py-2 text-xs font-extrabold text-slate-700"
          >
            Backup
          </button>
        </div>
      </header>
    );
  }

  function renderTabHeader(title: string, subtitle?: string) {
    return (
      <header
        className="border-b px-4"
        style={{
          backgroundColor: COLORS.background,
          borderBottomColor: COLORS.border,
          paddingTop: 22,
          paddingBottom: 20,
        }}
      >
        <h1 className="text-center text-[28px] font-black text-slate-950">{title}</h1>
        {subtitle && (
          <p className="mt-2 text-center text-[15px] font-medium leading-6 text-slate-500">
            {subtitle}
          </p>
        )}
      </header>
    );
  }

  function renderFilter(label: string, active: boolean, onClick: () => void) {
    return (
      <button
        type="button"
        onClick={() => {
          closeSelection();
          onClick();
        }}
        className={`flex-1 rounded-xl border px-3 py-2.5 text-[13px] font-extrabold ${
          active
            ? "border-[#2563EB] bg-[#2563EB] text-white"
            : "border-slate-200 bg-white text-slate-900"
        }`}
      >
        {label}
      </button>
    );
  }

  function renderHome() {
    return (
      <>
        {renderTabHeader("Links & Notas", "Guarde e proteja seus links favoritos e organize-os por pastas")}

        <div className="flex-1 overflow-y-auto px-4 py-4 pb-44">
          {homeSearch.trim() ? (
            <div className="grid gap-4">
              {homeResults.length === 0 ? (
                <div className="items-center py-8 text-center text-slate-500">
                  Nenhum link ou nota encontrado
                </div>
              ) : (
                <>
                  {homeResults.some((item) => item.kind === "link") && (
                    <div className="grid gap-2">
                      <p className="text-xs font-semibold uppercase text-slate-500">Meus Links</p>
                      {homeResults
                        .filter((item) => item.kind === "link")
                        .map((result) => (
                          <button
                            key={`home-link-${result.item.id}`}
                            type="button"
                            onClick={() => openTargetItem(result as Target)}
                            className="rounded-[18px] border-[1.5px] bg-white p-3 text-left active:opacity-75"
                            style={{ borderColor: COLORS.purple }}
                          >
                            <p className="truncate font-extrabold text-slate-950">🔗 {(result.item as CustomLink).title}</p>
                            <p className="mt-1 truncate text-sm text-slate-500">{getHost((result.item as CustomLink).url)}</p>
                          </button>
                        ))}
                    </div>
                  )}

                  {homeResults.some((item) => item.kind === "note") && (
                    <div className="grid gap-2">
                      <p className="text-xs font-semibold uppercase text-slate-500">Anotações</p>
                      {homeResults
                        .filter((item) => item.kind === "note")
                        .map((result) => {
                          const note = result.item as NoteItem;
                          return (
                            <button
                              key={`home-note-${note.id}`}
                              type="button"
                              onClick={() => openTargetItem(result as Target)}
                              className="rounded-[18px] border-[1.5px] p-3 text-left active:opacity-75"
                              style={{
                                backgroundColor: note.color ?? "#FFFFFF",
                                borderColor: COLORS.purple,
                              }}
                            >
                              <p className={`truncate font-extrabold ${note.color ? "text-white" : "text-slate-950"}`}>
                                📝 {note.title?.trim() || "Sem título"}
                              </p>
                              {note.content?.trim() && (
                                <p className={`mt-1 line-clamp-2 text-sm ${note.color ? "text-white/80" : "text-slate-500"}`}>
                                  {note.content}
                                </p>
                              )}
                            </button>
                          );
                        })}
                    </div>
                  )}

                  {homeResults.some((item) => item.kind === "linkFolder" || item.kind === "noteFolder") && (
                    <div className="grid gap-2">
                      <p className="text-xs font-semibold uppercase text-slate-500">Pastas</p>
                      {homeResults
                        .filter((item) => item.kind === "linkFolder" || item.kind === "noteFolder")
                        .map((result) => {
                          const isLinkFolder = result.kind === "linkFolder";
                          const folder: any = result.item;
                          return (
                            <button
                              key={`home-folder-${result.kind}-${folder.id}`}
                              type="button"
                              onClick={() => openTargetItem(result as Target)}
                              className="rounded-[18px] border-[1.5px] p-3 text-left active:opacity-75"
                              style={{ backgroundColor: COLORS.folderBackground, borderColor: COLORS.folderBorder }}
                            >
                              <p className="truncate font-extrabold text-slate-950">{folder.icon || "📁"} {folder.title || folder.name}</p>
                              <p className="mt-1 text-sm text-slate-500">{isLinkFolder ? "Pasta de Meus Links" : "Pasta de Anotações"}</p>
                            </button>
                          );
                        })}
                    </div>
                  )}
                </>
              )}
            </div>
          ) : (
            <div className="grid gap-[14px]">
              <HomeCard
                icon="🔗"
                overline="Repositório"
                title="MEUS LINKS"
                description="Guarde e proteja seus links favoritos e organize-os por pastas"
                onClick={() => {
                  setArea("links");
                  closeSelection();
                }}
              />

              <HomeCard
                icon="📝"
                overline="Bloco de notas"
                title="Anotações"
                description="Crie notas, proteja-as com senha e organize-as por pastas"
                onClick={() => {
                  setArea("notes");
                  closeSelection();
                }}
              />
            </div>
          )}
        </div>

        <div
          className="absolute left-0 right-0 z-20 px-4 pb-4 pt-3"
          style={{
            bottom: 68,
            backgroundColor: COLORS.background,
            borderTop: `1px solid ${COLORS.border}`,
          }}
        >
          <SearchBox value={homeSearch} onChange={setHomeSearch} placeholder="Buscar links e notas..." />
        </div>
      </>
    );
  }

  function renderLinks() {
    return (
      <>
        {renderHeader(activeLinkFolder?.title ?? "MEUS LINKS", activeLinkFolder ? "Pasta de links" : "Pastas, links e tudo")}

        {!linkFolderId && (
          <div className="flex gap-2 bg-[#F8FAFC] px-4 pt-3">
            {renderFilter("Pastas", linkMode === "folders", () => setLinkMode("folders"))}
            {renderFilter("Links", linkMode === "items", () => setLinkMode("items"))}
            {renderFilter("Tudo", linkMode === "all", () => setLinkMode("all"))}
          </div>
        )}

        <div className="flex-1 overflow-y-auto px-4 py-4 pb-36">
          {visibleLinkFolders.length > 0 && (
            <>
              <p className="mb-2 text-sm font-black text-slate-500">Pastas</p>
              <div className="mb-4 grid gap-3">
                {visibleLinkFolders.map((folder) => (
                  <FolderCard
                    key={folder.id}
                    icon={folder.icon}
                    title={folder.title}
                    subtitle={`${data.customLinks.filter((link) => link.folderId === folder.id).length} link(s)`}
                    onOpen={() => openTargetItem({ kind: "linkFolder", item: folder })}
                    onOptions={() => setTarget({ kind: "linkFolder", item: folder })}
                  />
                ))}
              </div>
            </>
          )}

          {visibleLinks.length > 0 && (
            <>
              {!linkFolderId && linkMode === "all" && (
                <p className="mb-2 text-sm font-black text-slate-500">Links</p>
              )}

              <div className="grid gap-3">
                {visibleLinks.map((link) => (
                  <LinkCard
                    key={link.id}
                    link={link}
                    onOpen={() => openTargetItem({ kind: "link", item: link })}
                    onOptions={() => setTarget({ kind: "link", item: link })}
                  />
                ))}
              </div>
            </>
          )}

          {visibleLinkFolders.length === 0 && visibleLinks.length === 0 && <EmptyState />}
        </div>

        <FabMenu area={area} folderOpen={Boolean(linkFolderId)} open={fabOpen} setOpen={setFabOpen} onCreateItem={() => startLink()} onCreateFolder={() => startLinkFolder()} />
      </>
    );
  }

  function renderNotes() {
    return (
      <>
        {renderHeader(activeNoteFolder?.name ?? "Anotações", activeNoteFolder ? "Pasta de anotações" : "Notas, pastas e tudo")}

        {!noteFolderId && (
          <div className="flex gap-2 bg-[#F8FAFC] px-4 pt-3">
            {renderFilter("Notas", noteMode === "items", () => setNoteMode("items"))}
            {renderFilter("Pastas", noteMode === "folders", () => setNoteMode("folders"))}
            {renderFilter("Tudo", noteMode === "all", () => setNoteMode("all"))}
          </div>
        )}

        <div className="flex-1 overflow-y-auto px-4 py-4 pb-36">
          {visibleNoteFolders.length > 0 && (
            <>
              <p className="mb-2 text-sm font-black text-slate-500">Pastas</p>
              <div className="mb-4 grid gap-3">
                {visibleNoteFolders.map((folder) => (
                  <FolderCard
                    key={folder.id}
                    icon={folder.icon}
                    title={folder.name}
                    subtitle={`${data.notes.filter((note) => note.folderId === folder.id).length} nota(s)`}
                    onOpen={() => openTargetItem({ kind: "noteFolder", item: folder })}
                    onOptions={() => setTarget({ kind: "noteFolder", item: folder })}
                  />
                ))}
              </div>
            </>
          )}

          {visibleNotes.length > 0 && (
            <>
              {!noteFolderId && noteMode === "all" && (
                <p className="mb-2 text-sm font-black text-slate-500">Notas</p>
              )}

              <div className="grid gap-3">
                {visibleNotes.map((note) => (
                  <NoteCard
                    key={note.id}
                    note={note}
                    onOpen={() => openTargetItem({ kind: "note", item: note })}
                    onOptions={() => setTarget({ kind: "note", item: note })}
                  />
                ))}
              </div>
            </>
          )}

          {visibleNoteFolders.length === 0 && visibleNotes.length === 0 && <EmptyState />}
        </div>

        <FabMenu area={area} folderOpen={Boolean(noteFolderId)} open={fabOpen} setOpen={setFabOpen} onCreateItem={() => startNote()} onCreateFolder={() => startNoteFolder()} />
      </>
    );
  }


  function openHistoryEntry(entry: HistoryEntry) {
    if (entry.kind === "link") {
      const link = data.customLinks.find((item) => item.id === entry.targetId);
      if (link) openTargetItem({ kind: "link", item: link });
      return;
    }

    if (entry.kind === "linkFolder") {
      const folder = data.customFolders.find((item) => item.id === entry.targetId);
      if (folder) openTargetItem({ kind: "linkFolder", item: folder });
      return;
    }

    if (entry.kind === "note") {
      const note = data.notes.find((item) => item.id === entry.targetId);
      if (note) openTargetItem({ kind: "note", item: note });
      return;
    }

    const folder = data.noteFolders.find((item) => item.id === entry.targetId);
    if (folder) openTargetItem({ kind: "noteFolder", item: folder });
  }

  function formatHistoryDateWeb(value: string) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";

    return date.toLocaleString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  function getHistoryIconWeb(item: HistoryEntry) {
    if (item.kind === "link") return "🔗";
    if (item.kind === "note") return "📝";
    if (item.kind === "linkFolder" || item.kind === "noteFolder") return "📂";
    return "📌";
  }

  function renderHistory() {
    return (
      <>
        <header
          className="border-b px-4 py-4"
          style={{ backgroundColor: COLORS.background, borderBottomColor: COLORS.border }}
        >
          <h1 className="text-[26px] font-black text-slate-950">Histórico</h1>
          <p className="mt-1 text-[15px] text-slate-500">Últimos itens abertos no aplicativo</p>
        </header>

        <div className="flex-1 overflow-y-auto px-4 py-4 pb-32">
          {history.length === 0 ? (
            <div
              className="rounded-[14px] border p-[18px] text-center text-sm text-slate-500"
              style={{ backgroundColor: COLORS.surface, borderColor: COLORS.border }}
            >
              Nenhum histórico salvo ainda.
            </div>
          ) : (
            <>
              <div className="grid gap-[10px]">
                {history.map((entry) => (
                  <button
                    key={`${entry.id}-${entry.createdAt}`}
                    type="button"
                    onClick={() => openHistoryEntry(entry)}
                    className="rounded-[18px] border-[1.5px] bg-white p-[14px] text-left active:opacity-75"
                    style={{ borderColor: COLORS.purple }}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{getHistoryIconWeb(entry)}</span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[16px] font-extrabold text-slate-950">{entry.title}</p>
                        <p className="mt-1 text-[12px] text-slate-500">{formatHistoryDateWeb(entry.createdAt)}</p>
                      </div>
                      <span className="text-[22px] text-slate-500">→</span>
                    </div>
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={() => {
                  if (window.confirm("Deseja apagar todo o histórico?")) setHistory([]);
                }}
                className="mt-4 w-full rounded-[14px] border p-[14px] text-center font-black text-red-600 active:opacity-75"
                style={{ backgroundColor: COLORS.surface, borderColor: COLORS.border }}
              >
                Limpar histórico
              </button>
            </>
          )}
        </div>
      </>
    );
  }

  function renderAbout() {
    return (
      <>
        <div className="flex-1 overflow-y-auto px-4 py-8 pb-32">
          <div className="flex flex-col items-center">
            <div
              className="flex h-24 w-24 items-center justify-center rounded-full border-2 text-5xl"
              style={{ backgroundColor: COLORS.surface, borderColor: COLORS.border }}
            >
              ❤️
            </div>
          </div>

          <div className="mt-6 flex flex-col items-center gap-2">
            <h1 className="text-3xl font-bold text-slate-950">Links Úteis</h1>
            <p className="text-sm text-slate-500">Versão {APP_VERSION}</p>
          </div>

          <div className="mt-6 grid gap-6">
            <AboutCard title="Sobre o Aplicativo">
              Links Úteis é um aplicativo que organiza seus links favoritos em categorias temáticas, permitindo acesso rápido e fácil a ferramentas, utilitários e recursos educacionais.
            </AboutCard>

            <AboutCard title="Desenvolvedor">
              <span className="font-medium text-[#2563EB]">Pericles Silva Reis</span>
              {"
"}periclesreis@bol.com.br
            </AboutCard>

            <AboutCard title="Categorias">
              • Utilitários: Ferramentas práticas do dia a dia{"
"}
              • JW.ORG - Estudos Bíblicos: Recursos de aprendizado{"
"}
              • JW.ORG - Vida Cristã: Orientações e inspiração
            </AboutCard>

            <div className="rounded-2xl bg-white p-6" style={{ backgroundColor: COLORS.surface }}>
              <p className="text-sm font-semibold text-slate-950">Contato</p>
              <div className="mt-4 grid gap-3">
                <a
                  href="mailto:periclesreis@bol.com.br"
                  className="rounded-lg px-4 py-3 text-center font-medium text-white"
                  style={{ backgroundColor: COLORS.primary }}
                >
                  📧 Enviar Email
                </a>
                <a
                  href="tel:+5577988122104"
                  className="rounded-lg px-4 py-3 text-center font-medium text-white"
                  style={{ backgroundColor: COLORS.primary }}
                >
                  📱 Ligar (77) 98812-2104
                </a>
              </div>
            </div>

            <div className="rounded-2xl bg-white p-6" style={{ backgroundColor: COLORS.surface }}>
              <p className="text-sm font-semibold text-slate-950">Redes Sociais</p>
              <div className="mt-4 grid gap-3">
                <a href="https://www.instagram.com/pericles.silvareis?igsh=MTJqdTk1ZWY1N2VtNA==" target="_blank" rel="noreferrer" className="rounded-lg px-4 py-3 text-center font-medium text-white" style={{ backgroundColor: "#E1306C" }}>
                  📸 Instagram
                </a>
                <a href="https://m.youtube.com/user/ericlesreis1?fbclid=PAb21jcARhqYlleHRuA2FlbQIxMQBzcnRjBmFwcF9pZA81NjcwNjczNDMzNTI0MjcAAaftioPaheAUVIPSowlJqgZGPHd47vQc_3EdT5gIgnHIFq_J3GI-X4qsaCqUIg_aem_MW_Pp8SlK7gPukWC-LJYsw" target="_blank" rel="noreferrer" className="rounded-lg px-4 py-3 text-center font-medium text-white" style={{ backgroundColor: "#FF0000" }}>
                  ▶️ YouTube
                </a>
                <a href="https://www.facebook.com/share/1B31efoLWm/" target="_blank" rel="noreferrer" className="rounded-lg px-4 py-3 text-center font-medium text-white" style={{ backgroundColor: "#1877F2" }}>
                  f Facebook
                </a>
              </div>
            </div>

            <div className="rounded-2xl bg-white p-6" style={{ backgroundColor: COLORS.surface }}>
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-slate-950">Histórico de Versões</p>
                <span className="rounded-full bg-[#2563EB] px-3 py-1 text-xs font-bold text-white">v{APP_VERSION}</span>
              </div>
              <div className="mt-4">
                <p className="text-sm font-medium text-[#2563EB]">v{APP_VERSION} - Versão web</p>
                <p className="mt-1 whitespace-pre-line text-xs leading-5 text-slate-500">
                  • Layout adaptado para web{"
"}• Meus Links e Anotações{"
"}• Backup local e importação
                </p>
              </div>
            </div>

            <p className="pb-4 text-center text-xs text-slate-500">
              Desenvolvido com ❤️ para facilitar seu acesso aos melhores recursos
            </p>
          </div>
        </div>
      </>
    );
  }

  function renderSettings() {
    const summary = {
      customFolders: data.customFolders.length,
      customLinks: data.customLinks.length,
      noteFolders: data.noteFolders.length,
      notes: data.notes.length,
      structuredNotes: 0,
    };

    return (
      <>
        <div className="flex-1 overflow-y-auto px-4 py-4 pb-32">
          <div className="grid gap-6">
            <div className="grid gap-1">
              <h1 className="text-[28px] font-black text-slate-950">Configurações</h1>
              <p className="text-[15px] leading-6 text-slate-500">Gerencie backup, restauração e dados do aplicativo.</p>
            </div>

            <div className="rounded-2xl border bg-white p-4" style={{ borderColor: COLORS.border }}>
              <div className="grid gap-1">
                <h2 className="text-xl font-black text-slate-950">💾 Backup</h2>
                <p className="text-sm leading-5 text-slate-500">
                  Exporte ou restaure um arquivo .lu com Meus Links, pastas, notas comuns e notas estruturadas.
                </p>
              </div>

              <div className="mt-4 grid gap-3">
                <button
                  type="button"
                  onClick={exportBackup}
                  className="rounded-xl p-[15px] text-center text-[16px] font-extrabold text-white active:opacity-80"
                  style={{ backgroundColor: COLORS.primary }}
                >
                  Exportar backup .lu
                </button>

                <label
                  className="block rounded-xl border p-[15px] text-center text-[16px] font-extrabold active:opacity-80"
                  style={{
                    backgroundColor: COLORS.background,
                    borderColor: COLORS.primary,
                    color: COLORS.primary,
                  }}
                >
                  Restaurar backup .lu
                  <input
                    type="file"
                    accept=".lu,.json,application/json"
                    className="hidden"
                    onChange={async (event) => {
                      const file = event.target.files?.[0];
                      if (file) importPayload(JSON.parse(await file.text()));
                    }}
                  />
                </label>
              </div>
            </div>

            <div className="rounded-2xl border bg-white p-4" style={{ borderColor: COLORS.border }}>
              <h2 className="text-[16px] font-extrabold text-slate-950">O que entra no backup?</h2>
              <p className="mt-2 whitespace-pre-line text-sm leading-6 text-slate-500">
                • Pastas e links criados em Meus Links{"
"}
                • Pastas de Anotações{"
"}
                • Notas comuns{"
"}
                • Notas estruturadas, como Assuntos para Pregação{"
"}
                • Compatibilidade com backup antigo .lu do Links Úteis
              </p>
            </div>

            <BackupSummaryCardWeb title="Resumo atual" summary={summary} />
          </div>
        </div>
      </>
    );
  }

  return (
    <main className="min-h-screen bg-slate-950 md:py-6">
      <div className="relative mx-auto flex h-screen max-w-[430px] flex-col overflow-hidden bg-[#F8FAFC] shadow-2xl md:h-[860px] md:rounded-[32px] md:border md:border-slate-800">
        {area === "home" && renderHome()}
        {area === "links" && renderLinks()}
        {area === "notes" && renderNotes()}
        {area === "history" && renderHistory()}
        {area === "about" && renderAbout()}
        {area === "settings" && renderSettings()}

        <FooterNav active={area} onChange={openFooterArea} />

        {target && (
          <ActionBar
            target={target}
            onOpen={() => openTargetItem(target)}
            onEdit={editTarget}
            onMove={() => setModal("move")}
            onColor={() => setModal("color")}
            onShare={shareTarget}
            onDelete={deleteTarget}
            onCancel={closeSelection}
          />
        )}
      </div>

      {modal === "link" && (
        <FormModal title={editId ? "Editar link" : "Novo link"} onSave={saveLink} onClose={closeModal}>
          <TextField label="Nome do link" value={fieldOne} onChange={setFieldOne} />
          <TextField label="Endereço" value={fieldTwo} onChange={setFieldTwo} placeholder="https://exemplo.com" />
          <FolderSelect
            value={selectedFolderId}
            onChange={setSelectedFolderId}
            folders={linkFolders.map((folder) => ({ id: folder.id, label: `${folder.icon} ${folder.title}` }))}
          />
        </FormModal>
      )}

      {modal === "linkFolder" && (
        <FormModal title={editId ? "Editar pasta" : "Nova pasta"} onSave={saveLinkFolder} onClose={closeModal}>
          <TextField label="Nome da pasta" value={fieldOne} onChange={setFieldOne} />
          <IconPicker value={selectedIcon} onChange={setSelectedIcon} />
        </FormModal>
      )}

      {modal === "note" && (
        <FormModal title={editId ? "Editar nota" : "Nova nota"} onSave={saveNote} onClose={closeModal}>
          <TextField label="Título" value={fieldOne} onChange={setFieldOne} />
          <label>
            <span className="mb-1 block text-sm font-bold text-slate-700">Anotação</span>
            <textarea
              value={fieldTwo}
              onChange={(event) => setFieldTwo(event.currentTarget.value)}
              onInput={(event) => setFieldTwo(event.currentTarget.value)}
              rows={8}
              className="w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-base outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100"
              style={{ color: "#0F172A", WebkitTextFillColor: "#0F172A", caretColor: "#2563EB", backgroundColor: "#FFFFFF" }}
            />
          </label>
          <FolderSelect
            value={selectedFolderId}
            onChange={setSelectedFolderId}
            folders={noteFolders.map((folder) => ({ id: folder.id, label: `${folder.icon} ${folder.name}` }))}
          />
        </FormModal>
      )}

      {modal === "noteFolder" && (
        <FormModal title={editId ? "Editar pasta" : "Nova pasta"} onSave={saveNoteFolder} onClose={closeModal}>
          <TextField label="Nome da pasta" value={fieldOne} onChange={setFieldOne} />
          <IconPicker value={selectedIcon} onChange={setSelectedIcon} />
        </FormModal>
      )}

      {modal === "move" && target && (
        <FormModal title="Mover" onClose={closeModal} hideSave>
          <div className="grid gap-2">
            <button
              type="button"
              onClick={() => moveTarget(null)}
              className="rounded-2xl border border-slate-300 px-4 py-3 text-left text-sm font-extrabold"
            >
              Sem pasta
            </button>

            {(target.kind === "link" ? linkFolders : noteFolders).map((folder: any) => (
              <button
                key={folder.id}
                type="button"
                onClick={() => moveTarget(folder.id)}
                className="rounded-2xl border border-slate-300 px-4 py-3 text-left text-sm font-extrabold"
              >
                {folder.icon} {folder.title || folder.name}
              </button>
            ))}
          </div>
        </FormModal>
      )}

      {modal === "color" && target?.kind === "note" && (
        <FormModal title="Mudar cor" onClose={closeModal} hideSave>
          <div className="grid max-h-[60vh] grid-cols-2 gap-2 overflow-y-auto">
            {NOTE_COLORS.map((color) => (
              <button
                key={color.label}
                type="button"
                onClick={() => applyColor(color.value)}
                className="rounded-2xl border border-slate-300 px-3 py-3 text-sm font-extrabold"
                style={
                  color.value
                    ? {
                        backgroundColor: color.value,
                        color: "#fff",
                        borderColor: color.value,
                      }
                    : undefined
                }
              >
                {color.label}
              </button>
            ))}
          </div>
        </FormModal>
      )}

      {backupOpen && (
        <FormModal title="Backup" onClose={() => setBackupOpen(false)} hideSave>
          <p className="text-sm leading-6 text-slate-600">
            Exporte, importe por arquivo ou leia um backup salvo em nuvem por link direto.
          </p>

          <button
            type="button"
            onClick={exportBackup}
            className="rounded-2xl bg-[#2563EB] px-4 py-3 text-sm font-extrabold text-white"
          >
            Exportar backup
          </button>

          <label className="block rounded-2xl border border-slate-300 px-4 py-3 text-center text-sm font-extrabold">
            Importar arquivo .lu
            <input
              type="file"
              accept=".lu,.json,application/json"
              className="hidden"
              onChange={async (event) => {
                const file = event.target.files?.[0];

                if (file) {
                  importPayload(JSON.parse(await file.text()));
                }
              }}
            />
          </label>

          <input
            value={importUrl}
            onChange={(event) => setImportUrl(event.currentTarget.value)}
            onInput={(event) => setImportUrl(event.currentTarget.value)}
            placeholder="Cole o link do backup"
            className="w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-base outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100"
            style={{ color: "#0F172A", WebkitTextFillColor: "#0F172A", caretColor: "#2563EB", backgroundColor: "#FFFFFF" }}
          />

          <button
            type="button"
            onClick={importByUrl}
            className="rounded-2xl border border-[#94A3B8] bg-[#E5E7EB] px-4 py-3 text-sm font-extrabold text-slate-900"
          >
            Importar por link
          </button>

          <button
            type="button"
            onClick={clearLocalData}
            className="rounded-2xl bg-red-600 px-4 py-3 text-sm font-extrabold text-white"
          >
            Limpar dados locais
          </button>
        </FormModal>
      )}
    </main>
  );
}


function FooterNav({
  active,
  onChange,
}: {
  active: Area;
  onChange: (area: Area) => void;
}) {
  const items: { area: Area; label: string; icon: string }[] = [
    { area: "home", label: "Home", icon: "⌂" },
    { area: "history", label: "Histórico", icon: "‹/›" },
    { area: "about", label: "Sobre", icon: "➤" },
    { area: "settings", label: "Configurações", icon: "⚙️" },
  ];

  return (
    <nav
      className="absolute inset-x-0 bottom-0 z-10 border-t px-2"
      style={{
        backgroundColor: COLORS.background,
        borderTopColor: COLORS.border,
        paddingTop: 8,
        paddingBottom: 12,
        height: 68,
      }}
    >
      <div className="grid grid-cols-4 gap-1">
        {items.map((item) => {
          const selected = active === item.area;

          return (
            <button
              key={item.area}
              type="button"
              onClick={() => onChange(item.area)}
              className="rounded-xl px-1 py-1 text-center"
              style={{ color: selected ? COLORS.primary : COLORS.muted }}
            >
              <span className="block text-[22px] leading-none">{item.icon}</span>
              <span className="mt-1 block truncate text-[11px] font-bold">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

function AboutCard({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded-2xl bg-white p-6" style={{ backgroundColor: COLORS.surface }}>
      <p className="text-sm font-semibold text-slate-950">{title}</p>
      <p className="mt-2 whitespace-pre-line text-sm leading-6 text-slate-500">{children}</p>
    </div>
  );
}

function BackupSummaryCardWeb({
  title,
  summary,
}: {
  title: string;
  summary: {
    customFolders: number;
    customLinks: number;
    noteFolders: number;
    notes: number;
    structuredNotes: number;
  };
}) {
  return (
    <div className="rounded-[14px] border bg-white p-4" style={{ borderColor: COLORS.border }}>
      <h2 className="text-[16px] font-extrabold text-slate-950">{title}</h2>
      <div className="mt-3 grid gap-2">
        <SummaryRowWeb label="Pastas de Meus Links" value={summary.customFolders} />
        <SummaryRowWeb label="Links personalizados" value={summary.customLinks} />
        <SummaryRowWeb label="Pastas de Anotações" value={summary.noteFolders} />
        <SummaryRowWeb label="Notas comuns" value={summary.notes} />
        <SummaryRowWeb label="Notas estruturadas" value={summary.structuredNotes} />
      </div>
    </div>
  );
}

function SummaryRowWeb({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-sm text-slate-500">{label}</span>
      <span className="text-sm font-bold text-slate-950">{value}</span>
    </div>
  );
}

function InfoCard({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded-[18px] border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="text-[16px] font-black text-slate-950">{title}</h3>
      <p className="mt-2 whitespace-pre-line text-sm leading-6 text-slate-600">{children}</p>
    </div>
  );
}

function HomeCard({
  icon,
  overline,
  title,
  description,
  onClick,
}: {
  icon: string;
  overline: string;
  title: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="h-[220px] overflow-hidden rounded-[20px] text-left shadow-lg active:opacity-90"
      style={{
        background: CARD_GRADIENT,
        boxShadow: "0 5px 10px rgba(29, 78, 216, 0.16)",
      }}
    >
      <div
        className="flex h-full flex-col justify-between rounded-[20px] p-[18px]"
        style={{ border: "1px solid #93C5FD" }}
      >
        <div>
          <span className="mb-[14px] block text-[40px] leading-none">{icon}</span>
          <h2 className="text-2xl font-bold text-white">{title}</h2>
          <p className="mt-3 text-base leading-6 text-white/85">{description}</p>
        </div>
        <div className="text-right text-3xl text-white">→</div>
      </div>
    </button>
  );
}

function SearchBox({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
}) {
  return (
    <label className="flex items-center gap-2 rounded-[18px] border border-slate-200 bg-white px-3 py-2.5 shadow-sm focus-within:border-[#2563EB] focus-within:ring-2 focus-within:ring-blue-100">
      <span className="text-lg text-slate-400">🔎</span>
      <input
        value={value}
        onChange={(event) => onChange(event.currentTarget.value)}
        onInput={(event) => onChange(event.currentTarget.value)}
        placeholder={placeholder}
        className="min-w-0 flex-1 bg-transparent text-[15px] font-semibold text-slate-900 outline-none placeholder:text-slate-400"
        style={{ color: "#0F172A", WebkitTextFillColor: "#0F172A", caretColor: "#2563EB" }}
      />
      {value && (
        <button type="button" onClick={() => onChange("")} className="rounded-full bg-slate-100 px-2 py-1 text-xs font-black text-slate-500">
          Limpar
        </button>
      )}
    </label>
  );
}

function FolderCard({
  icon,
  title,
  subtitle,
  onOpen,
  onOptions,
}: {
  icon: string;
  title: string;
  subtitle: string;
  onOpen: () => void;
  onOptions: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onOpen}
      className="rounded-[18px] border-[1.5px] p-3.5 text-left shadow-sm active:opacity-70"
      style={{ backgroundColor: "#E0F2FE", borderColor: "#38BDF8" }}
    >
      <div className="flex items-center gap-3">
        <span className="text-3xl">{icon || "📁"}</span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[16px] font-extrabold text-slate-950">{title}</p>
          <p className="mt-1 text-[13px] text-slate-500">{subtitle}</p>
        </div>
        <button
          type="button"
          onClick={(event) => {
            event.stopPropagation();
            onOptions();
          }}
          className="rounded-full px-2 py-1 text-xl text-slate-500"
          aria-label="Opções"
        >
          ⋯
        </button>
      </div>
    </button>
  );
}

function LinkCard({
  link,
  onOpen,
  onOptions,
}: {
  link: CustomLink;
  onOpen: () => void;
  onOptions: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onOpen}
      className="rounded-[18px] border-[1.5px] p-3.5 text-left shadow-sm active:opacity-70"
      style={{ backgroundColor: "#FFFFFF", borderColor: "#7C3AED" }}
    >
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0 flex-1">
          <p className="truncate text-[16px] font-bold text-slate-950">🔗 {link.title}</p>
          <p className="mt-1 truncate text-[13px] text-slate-500">{getHost(link.url)}</p>
        </div>
        <button
          type="button"
          onClick={(event) => {
            event.stopPropagation();
            onOptions();
          }}
          className="rounded-full px-2 py-1 text-xl text-slate-500"
          aria-label="Opções"
        >
          ⋯
        </button>
        <span className="text-2xl text-slate-400">→</span>
      </div>
    </button>
  );
}

function NoteCard({
  note,
  onOpen,
  onOptions,
}: {
  note: NoteItem;
  onOpen: () => void;
  onOptions: () => void;
}) {
  const colored = Boolean(note.color);

  return (
    <button
      type="button"
      onClick={onOpen}
      className="rounded-[18px] border-[1.5px] p-3.5 text-left shadow-sm active:opacity-70"
      style={{
        backgroundColor: note.color || "#FFFFFF",
        borderColor: COLORS.purple,
      }}
    >
      <div className="flex items-center gap-3">
        <span className="text-2xl">📝</span>
        <div className="min-w-0 flex-1">
          <p className={`truncate text-[18px] font-extrabold ${colored ? "text-white" : "text-slate-950"}`}>
            {note.title || "Sem título"}
          </p>

          {note.content && (
            <p className={`mt-1 line-clamp-2 text-[13px] ${colored ? "text-white/80" : "text-slate-500"}`}>{note.content}</p>
          )}

          <p className={`mt-2 text-[12px] ${colored ? "text-white/70" : "text-slate-400"}`}>{formatDate(note.updatedAt)}</p>
        </div>

        <button
          type="button"
          onClick={(event) => {
            event.stopPropagation();
            onOptions();
          }}
          className={`rounded-full px-2 py-1 text-xl ${colored ? "text-white/80" : "text-slate-500"}`}
          aria-label="Opções"
        >
          ⋯
        </button>
      </div>
    </button>
  );
}

function FabMenu({
  area,
  folderOpen,
  open,
  setOpen,
  onCreateItem,
  onCreateFolder,
}: {
  area: Area;
  folderOpen: boolean;
  open: boolean;
  setOpen: (value: boolean | ((previous: boolean) => boolean)) => void;
  onCreateItem: () => void;
  onCreateFolder: () => void;
}) {
  if (area === "home") {
    return null;
  }

  const itemLabel = area === "links" ? "+ Link" : "+ Nota";
  const itemIcon = area === "links" ? "🔗" : "📝";
  const itemColor = area === "links" ? "#2563EB" : "#7C3AED";

  return (
    <div className="absolute bottom-[86px] right-5 z-20 flex flex-col items-end gap-3">
      {open && (
        <div className="min-w-[172px] overflow-hidden rounded-2xl border border-blue-100 bg-white p-2 shadow-xl">
          <button
            type="button"
            onClick={onCreateItem}
            className="mb-2 flex w-full items-center gap-2 rounded-xl px-4 py-3 text-left text-sm font-extrabold text-white shadow-sm active:opacity-80"
            style={{ backgroundColor: itemColor }}
          >
            <span className="text-lg">{itemIcon}</span>
            <span>{itemLabel}</span>
          </button>

          {!folderOpen && (
            <button
              type="button"
              onClick={onCreateFolder}
              className="flex w-full items-center gap-2 rounded-xl border border-[#38BDF8] bg-[#E0F2FE] px-4 py-3 text-left text-sm font-extrabold text-slate-900 active:opacity-80"
            >
              <span className="text-lg">📁</span>
              <span>+ Pasta</span>
            </button>
          )}
        </div>
      )}

      <button
        type="button"
        onClick={() => setOpen((previous) => !previous)}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-[#2563EB] text-3xl font-light text-white shadow-xl active:opacity-75"
        aria-label="Criar"
      >
        +
      </button>
    </div>
  );
}

function ActionBar({
  target,
  onOpen,
  onEdit,
  onMove,
  onColor,
  onShare,
  onDelete,
  onCancel,
}: {
  target: Target;
  onOpen: () => void;
  onEdit: () => void;
  onMove: () => void;
  onColor: () => void;
  onShare: () => void;
  onDelete: () => void;
  onCancel: () => void;
}) {
  const isFolder = target.kind === "linkFolder" || target.kind === "noteFolder";
  const canMove = target.kind === "link" || target.kind === "note";

  return (
    <div className="absolute inset-x-0 bottom-0 z-30 border-t border-[#94A3B8] bg-[#E5E7EB] px-2 py-2 shadow-2xl">
      <div className="flex gap-1 overflow-x-auto">
        <ActionButton onClick={onOpen}>Abrir</ActionButton>
        <ActionButton onClick={onEdit}>Editar</ActionButton>
        {canMove && <ActionButton onClick={onMove}>Mover</ActionButton>}
        {target.kind === "note" && <ActionButton onClick={onColor}>Cor</ActionButton>}
        {!isFolder && <ActionButton onClick={onShare}>Enviar</ActionButton>}
        <button type="button" onClick={onDelete} className="min-w-20 rounded-xl border border-red-300 bg-red-600 px-3 py-2 text-xs font-extrabold text-white">
          Excluir
        </button>
        <ActionButton onClick={onCancel}>Cancelar</ActionButton>
      </div>
    </div>
  );
}

function ActionButton({ children, onClick }: { children: ReactNode; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="min-w-20 rounded-xl border border-[#94A3B8] bg-white px-3 py-2 text-xs font-extrabold text-slate-900">
      {children}
    </button>
  );
}

function EmptyState() {
  return (
    <div className="mt-10 rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-center text-sm text-slate-500">
      Nenhum item encontrado.
    </div>
  );
}

function TextField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <label>
      <span className="mb-1 block text-sm font-bold text-slate-700">{label}</span>
      <input
        value={value}
        onChange={(event) => onChange(event.currentTarget.value)}
        onInput={(event) => onChange(event.currentTarget.value)}
        placeholder={placeholder}
        className="w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-base outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100"
        style={{ color: "#0F172A", WebkitTextFillColor: "#0F172A", caretColor: "#2563EB", backgroundColor: "#FFFFFF" }}
      />
    </label>
  );
}

function FolderSelect({
  value,
  onChange,
  folders,
}: {
  value: string | null;
  onChange: (value: string | null) => void;
  folders: { id: string; label: string }[];
}) {
  return (
    <label>
      <span className="mb-1 block text-sm font-bold text-slate-700">Pasta</span>
      <select
        value={value || ""}
        onChange={(event) => onChange(event.target.value || null)}
        className="w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-base outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100"
      >
        <option value="">Sem pasta</option>
        {folders.map((folder) => (
          <option key={folder.id} value={folder.id}>
            {folder.label}
          </option>
        ))}
      </select>
    </label>
  );
}

function IconPicker({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return (
    <div>
      <span className="mb-2 block text-sm font-bold text-slate-700">Ícone</span>
      <div className="flex flex-wrap gap-2">
        {ICONS.map((icon) => (
          <button
            key={icon}
            type="button"
            onClick={() => onChange(icon)}
            className={`rounded-xl border px-3 py-2 text-xl ${
              value === icon ? "border-[#2563EB] bg-blue-50" : "border-slate-300"
            }`}
          >
            {icon}
          </button>
        ))}
      </div>
    </div>
  );
}

function FormModal({
  title,
  children,
  onSave,
  onClose,
  hideSave,
}: {
  title: string;
  children: ReactNode;
  onSave?: () => void;
  onClose: () => void;
  hideSave?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 px-4">
      <div className="w-full max-w-[390px] rounded-3xl bg-white p-4 shadow-2xl">
        <h2 className="text-xl font-black text-slate-950">{title}</h2>

        <div className="mt-4 grid gap-3">{children}</div>

        <div className="mt-4 flex gap-2">
          <button type="button" onClick={onClose} className="flex-1 rounded-2xl border border-[#94A3B8] bg-[#E5E7EB] px-4 py-3 text-sm font-extrabold text-slate-900">
            Cancelar
          </button>

          {!hideSave && (
            <button type="button" onClick={onSave} className="flex-1 rounded-2xl bg-[#2563EB] px-4 py-3 text-sm font-extrabold text-white">
              Salvar
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
